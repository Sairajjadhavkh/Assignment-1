class Problem2{
public static void main(String args[]){
System.out.println("Addition of a and b is: "+(74+36));
}
}