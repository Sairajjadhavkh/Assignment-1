class Problem9
{
	public static void main(String args[])
	{
		System.out.println(((25.5*3.5-3.5-3.5)/(40.5-4.5)));
	}
}