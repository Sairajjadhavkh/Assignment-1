class Problem11
{
public static void main(String args[])
{
	float r=7.5f;
	float a=(float)(3.14*r*r);
	float p=(float)(2*3.14*r);
	System.out.println("Perimeter is ="+p);
	System.out.println("Area is ="+a);
}
}