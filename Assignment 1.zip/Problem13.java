class Problem13
{
public static void main(String args[])
{
	System.out.println("Area is 5.6*8.5="+(5.6*8.5));
	System.out.println("Perimeter is 2 * (5.6 + 8.5) ="+ (2*(5.6 + 8.5)));
}
}