class Problem3{
public static void main(String args[]){
System.out.println("Division of a and b is: "+(50/3));
}
}