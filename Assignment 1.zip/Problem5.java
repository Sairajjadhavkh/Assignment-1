import java.util.*;
class Problem5{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
System.out.print("Input first number: ");
int a=sc.nextInt();
System.out.print("Input second number: ");
int b=sc.nextInt();
System.out.println("25 x 5 ="+125);
}
}